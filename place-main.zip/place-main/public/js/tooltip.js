$(function(){$("[data-tooltip=\"yes\"]").tooltip()})
