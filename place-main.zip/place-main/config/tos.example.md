# Place 2.0 Terms of Service
**Last updated:** date of modification

---

Give your users a TOS to agree to. If this is enabled (by the existence of `tos.md`), users must check a box at sign up and they will see a link to this in the footer. Every time this document changes, the existing users will need to accept it once again.