# Community Guidelines
**Last updated:** date of modification

---

Give your users some rules to follow. If this is enabled (by the existence of `community_guidelines.md`), users must check a box at sign up and they will see a link to this in the footer.